const express = require("express");
const dotenv = require("dotenv").config();
const cors = require("cors");
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");
const path = require("path");
const AWS = require("aws-sdk");
const app = express();

// Database connection
mongoose
  .connect(process.env.MONGO_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Database Connected"))
  .catch((err) => console.error("Database connection error:", err));

// AWS SDK configuration
const s3 = new AWS.S3();

// Middleware
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: false }));
app.use(cors()); // Enable CORS for all routes

app.get("*.mjs", (req, res, next) => {
  res.header("Content-Type", "application/javascript");
  next();
});

// Serve React app from S3 bucket
app.use("/", express.static(path.join(__dirname, "../Client/build")));

// API routes
app.use("/", require("./routes/authRoutes"));

// Catch-all route to serve the React app for any other routes
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../Client/build", "index.html"));
});

const port = process.env.PORT || 8000;
app.listen(port, () => console.log(`Server is running on port ${port}`));
